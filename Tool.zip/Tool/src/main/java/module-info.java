module cn.mi.tool {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires java.sql;


    opens cn.mi.tool to javafx.fxml;
    exports cn.mi.tool;
}