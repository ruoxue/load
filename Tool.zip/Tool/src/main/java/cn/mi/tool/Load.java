package cn.mi.tool;

import com.github.kiulian.downloader.Config;
import com.github.kiulian.downloader.YoutubeDownloader;
import com.github.kiulian.downloader.downloader.YoutubeProgressCallback;
import com.github.kiulian.downloader.downloader.request.RequestChannelUploads;
import com.github.kiulian.downloader.downloader.request.RequestPlaylistInfo;
import com.github.kiulian.downloader.downloader.request.RequestVideoFileDownload;
import com.github.kiulian.downloader.downloader.request.RequestVideoInfo;
import com.github.kiulian.downloader.downloader.response.Response;
import com.github.kiulian.downloader.model.playlist.PlaylistDetails;
import com.github.kiulian.downloader.model.playlist.PlaylistInfo;
import com.github.kiulian.downloader.model.playlist.PlaylistVideoDetails;
import com.github.kiulian.downloader.model.videos.VideoInfo;
import com.github.kiulian.downloader.model.videos.formats.Format;

import java.io.File;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Load {
    public static YoutubeDownloader getDownloader() {
        Config config = new Config.Builder()
                .executorService(Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors()*4)) // for async requests, default Executors.newCachedThreadPool()
                .maxRetries(1) // retry on failure, default 0
                .header("Accept-language", "en-US,en;") // extra request header
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36")


//                .proxy("192.168.0.1", 2005)
//                .proxyCredentialsManager(proxyCredentials) // default ProxyCredentialsImpl
//                .proxy("192.168.0.1", 2005, "login", "pass")
                .build();
        YoutubeDownloader downloader = new YoutubeDownloader(config);
        return downloader;
    }

    public static void loadSync(String videoId, OnDownListener onDownListener) {
        try {
            YoutubeDownloader downloader = getDownloader();
            File outputDir = new File(System.getProperty("user.dir") + File.separator + "down");
            RequestVideoInfo requestVideoInfo = new RequestVideoInfo(videoId);

            Response<VideoInfo> videoInfo = downloader.getVideoInfo(requestVideoInfo);
            Format format = videoInfo.data().formats().get(0);

            System.out.println("videoInfo.data().details() = " + videoInfo.data().details().title());

            RequestVideoFileDownload requestVideoFileDownload = new RequestVideoFileDownload(format)
                    .saveTo(outputDir)

                    .maxRetries(3)

                    .renameTo(videoInfo.data().details().title()) // by default file name will be same as video title on youtube

                    .callback(new YoutubeProgressCallback<File>() {
                        @Override
                        public void onDownloading(int progress) {
                            System.out.printf("Downloaded %d%%\n", progress);
                            onDownListener.onDownloading(progress, videoInfo.data().details().title());
                        }

                        @Override
                        public void onFinished(File videoInfo) {
                            System.out.println("Finished file: " + videoInfo);
                            onDownListener.onFinished(videoInfo);
                        }

                        @Override
                        public void onError(Throwable throwable) {
                            System.out.println("Error: " + throwable.getLocalizedMessage());
                            onDownListener.onError(throwable);
                        }
                    }).async();

            Response<File> response = downloader.downloadVideoFile(requestVideoFileDownload);
        } catch (Exception e) {
            System.out.println("e = " + e);
            onDownListener.onError(e);
        }
    }

    public static void load(String videoId) {
        Config config = new Config.Builder()
                .executorService(Executors.newFixedThreadPool(10)) // for async requests, default Executors.newCachedThreadPool()
                .maxRetries(1) // retry on failure, default 0
                .header("Accept-language", "en-US,en;") // extra request header
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36")


//                .proxy("192.168.0.1", 2005)
//                .proxyCredentialsManager(proxyCredentials) // default ProxyCredentialsImpl
//                .proxy("192.168.0.1", 2005, "login", "pass")
                .build();
        YoutubeDownloader downloader = new YoutubeDownloader(config);
        File outputDir = new File(System.getProperty("user.dir") + File.separator + "down");
        RequestVideoInfo requestVideoInfo = new RequestVideoInfo(videoId);

        Response<VideoInfo> videoInfo = downloader.getVideoInfo(requestVideoInfo);
        Format format = videoInfo.data().formats().get(0);
        System.out.println("format = " + format);

        RequestVideoFileDownload request = new RequestVideoFileDownload(format)
                // optional params
                .saveTo(outputDir) // by default "videos" directory
                .renameTo(videoInfo.data().details().title()) // by default file name will be same as video title on youtube
                .overwriteIfExists(true); // if false and file with such name already exits sufix will be added video(1).mp4
        Response<File> response = downloader.downloadVideoFile(request);


    }

    public static void loadListSync(String playlistId, OnDownListener onDownListener) {
        try {

            RequestPlaylistInfo request = new RequestPlaylistInfo(playlistId);
            YoutubeDownloader downloader = getDownloader();

            Response<PlaylistInfo> response = downloader.getPlaylistInfo(request);
            PlaylistInfo playlistInfo = response.data();

// playlist details
            PlaylistDetails details = playlistInfo.details();
            System.out.println(details.title());
            System.out.println(details.videoCount());

            for (int i = playlistInfo.videos().size() - 1; i >= 0; i--) {
                loadSync(playlistInfo.videos().get(i).videoId(), onDownListener);
            }

        } catch (Exception e) {
            System.out.println("e = " + e);
            onDownListener.onError(e);
        }

    }

    public static void loadChannel(String channelId, OnDownListener onDownListener) {
        try {
            channelId= URLEncoder.encode(channelId);
            System.out.println("channelId = " + channelId);
            RequestChannelUploads request = new RequestChannelUploads(channelId);
            Response<PlaylistInfo> response = getDownloader().getChannelUploads(request);
            PlaylistInfo playlistInfo = response.data();

            for (int i = playlistInfo.videos().size() - 1; i >= 0; i--) {
                System.out.println("playlistInfo.videos().get(i).title() = " + playlistInfo.videos().get(i).title());
                loadSync(playlistInfo.videos().get(i).videoId(), onDownListener);
            }
        } catch (Exception e) {
            System.out.println("e = " + e);
            System.out.println("e = " + e);
            onDownListener.onError(e);
        }
    }
}
