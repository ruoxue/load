package cn.mi.tool;//package cn.mi.tools;


import com.github.kiulian.downloader.downloader.request.RequestPlaylistInfo;
import com.github.kiulian.downloader.model.playlist.PlaylistInfo;

public class Loads {

    public static void main(String[] args) {

//        String url = "PLsw2iU9xmpfbFhcGwniopja0U3O1-ifzL";
//        Load.loadListSync(url, null);

        String url = "CCTV少儿官方频道CCTVChildrenOfficialChannel";
        Load.loadChannel(url, null);

//        try {
//            Document document = Jsoup.connect(url).get();
//            Elements script =   document.getElementsByTag("script");
//
//
//            for (Element element : script) {
//                System.out.println("element = " + element);
//                if (element.html().contains("videoId")){
//
//                    String html = element.html();
//                    System.out.println("html = " + html);
//
//                    html = html.substring(html.indexOf("{"),html.lastIndexOf(";"));
//
//
//                    JSONObject jsonObject = JSON.parseObject(html);
//
//
//
//                    JSONObject contents = jsonObject.getJSONObject("contents")
//                            .getJSONObject("twoColumnBrowseResultsRenderer")
//                            .getJSONArray("tabs").getJSONObject(0)
//                            .getJSONObject("tabRenderer").getJSONObject("content")
//                            .getJSONObject("sectionListRenderer")
//                            .getJSONArray("contents").getJSONObject(0)
//                            .getJSONObject("itemSectionRenderer")
//                            .getJSONArray("contents").getJSONObject(0)
//                            .getJSONObject("playlistVideoListRenderer")  ;
//
//                    JSONArray contents1 = contents.getJSONArray("contents");
//
//
//                    for (int i =0 ; i <contents1.size() ; i++) {
//
//                        if (i<31){
//                            continue;
//                        }
////	enPwd	"	enPwd	"11f60a58d2d63dd9255333672ebb3ffc"	"
//                        JSONObject jsonObject1 = contents1.getJSONObject(i);
//
//                        String videoId = jsonObject1.getJSONObject("playlistVideoRenderer").getString("videoId");
//
//                        System.out.println("jsonObject1 = " + videoId);
//                        Load.load(videoId);
//                    }
//
//
//                }
//            }
//
//
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

    }
}
