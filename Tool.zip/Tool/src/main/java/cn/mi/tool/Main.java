package cn.mi.tool;

import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class Main {

    public static void main(String[] args) throws InterruptedException {

        AdbUtil adbc = new AdbUtil();
        AtomicInteger j = new AtomicInteger();
        AtomicReference<String> s = new AtomicReference<>("come");
        int x = 50;
        int y = 1300;

        do {
            Executors.newFixedThreadPool(138).execute(() -> {

//            adbc.keyevent(Even.KEYCODE_ENTER);
                adbc.click(x, y);
//            adbc.keyevent(Even.KEYCODE_ENTER);
//            adbc.click(1858, 302);
                j.getAndIncrement();
                System.out.println("j = " + j);
                s.set("comn");
//            adbc.power();
//            adbc.keyevent(Even.KEYCODE_MENU);
//            for (int i = 0; i < 3; i++) {
//                adbc.keyevent(Even.KEYCODE_DEL);
//            }
                adbc.input(s.get());
                adbc.click(60, 690);
//            adbc.input(s);
//            adbc.click(x, y);
//            adbc.keyevent(Even.KEYCODE_ENTER);
            });
            Thread.sleep(6 * 1000);
        } while (true);
    }
}
