package cn.mi.tool;

import java.io.File;

public interface OnDownListener {
    void onDownloading(int pro,String name);

    void onFinished(File var1);

    void onError(Throwable var1);
}
