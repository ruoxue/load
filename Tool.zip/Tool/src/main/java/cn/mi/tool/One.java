package cn.mi.tool;

import java.io.File;
import java.util.concurrent.Executors;

public class One {
    public static void main(String[] args) {
        //10  19 21  23 27 29 39 40 41 42 45 46 47 49 50

//
//        Executors.newFixedThreadPool(9).execute(()->{
            Load.loadSync("H6cl65uxHQc", new OnDownListener() {
                @Override
                public void onDownloading(int pro, String name) {

                }

                @Override
                public void onFinished(File var1) {

                }

                @Override
                public void onError(Throwable var1) {

                }
            });

//        });
    }
}
