package cn.mi.tool;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.File;
import java.io.IOException;
import java.util.Optional;

public class DownController {

    @FXML
    public TextField idVideo;
    @FXML
    public ProgressIndicator idPb;
    @FXML
    public Label idFileName;
    @FXML
    public TextField idListVideo;
    @FXML
    public TextField idChannelVideo;

    public void sendAdb(ActionEvent actionEvent) {
        HelloApplication helloApplication = HelloApplication.getApp();
        helloApplication.show(HelloApplication.class.getResource("hello-view.fxml"));

    }

    public void down(ActionEvent actionEvent) {

        String trim = idVideo.getText().trim();
        Platform.runLater(() -> {


            idPb.setVisible(true);
            idPb.setProgress(ProgressIndicator.INDETERMINATE_PROGRESS);
        });
        Load.loadSync(trim, new OnDownListener() {
            @Override
            public void onDownloading(int i, String name) {
                System.out.println("i = " + i);
                Platform.runLater(() -> {
                    double i1 = i * 0.01;
                    idFileName.setText(name);
                    idPb.setProgress(i1);
                });
            }

            @Override
            public void onFinished(File file) {
                Platform.runLater(() -> {
                    idPb.setProgress(1);
                    idFileName.setVisible(true);
                    idFileName.setText(file.getAbsolutePath());
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);

                    alert.setTitle("打开文件目录？");
                    alert.setContentText("打开文件目录");
                    Optional<ButtonType> buttonType = alert.showAndWait();
                    if (buttonType.get().getButtonData().equals(ButtonBar.ButtonData.OK_DONE)) {
                        try {
                            java.awt.Desktop.getDesktop().open(file.getParentFile());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }

            @Override
            public void onError(Throwable throwable) {
                Platform.runLater(() -> {
                    System.out.println("throwable = " + throwable);
                    idFileName.setVisible(true);
                    idFileName.setText("请重新下载" + throwable.getLocalizedMessage());
                    idPb.setProgress(0);
                });
            }
        });


    }

    public void exit(ActionEvent actionEvent) {
        HelloApplication.getApp().close();
    }

    public void downList(ActionEvent actionEvent) {

        String trim = idListVideo.getText().trim();
        Platform.runLater(() -> {
            idPb.setVisible(true);
            idPb.setProgress(ProgressIndicator.INDETERMINATE_PROGRESS);
        });
        Load.loadListSync(trim, new OnDownListener() {
            @Override
            public void onDownloading(int i, String name) {
                System.out.println("i = " + i);
                Platform.runLater(() -> {

                    double i1 = i * 0.01;
                    idFileName.setText(name);
                    System.out.println("i1 = " + i1);
                    idPb.setProgress(i1);
                });
            }

            @Override
            public void onFinished(File file) {
                Platform.runLater(() -> {
                    idPb.setProgress(1);
                    idFileName.setVisible(true);
                    idFileName.setText(file.getAbsolutePath());
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("打开文件目录？");
                    alert.setContentText("打开文件目录");
                    Optional<ButtonType> buttonType = alert.showAndWait();
                    if (buttonType.get().getButtonData().equals(ButtonBar.ButtonData.OK_DONE)) {
                        try {
                            java.awt.Desktop.getDesktop().open(file.getParentFile());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }

            @Override
            public void onError(Throwable throwable) {
                Platform.runLater(() -> {
                    System.out.println("throwable = " + throwable);
                    idFileName.setVisible(true);
                    idFileName.setText("请重新下载" + throwable.getLocalizedMessage());
                    idPb.setProgress(0);
                });
            }
        });
    }

    public void downChannel(ActionEvent actionEvent) {

        String trim = idChannelVideo.getText().trim();
        Platform.runLater(() -> {
            idPb.setVisible(true);
            idPb.setProgress(ProgressIndicator.INDETERMINATE_PROGRESS);
        });
        Load.loadChannel(trim, new OnDownListener() {
            @Override
            public void onDownloading(int i, String name) {
                System.out.println("i = " + i);
                Platform.runLater(() -> {


                    idPb.setVisible(true);
                    double i1 = i * 0.01;
                    idFileName.setText(name);
                    System.out.println("i1 = " + i1);
                    idPb.setProgress(i1);
                });
            }

            @Override
            public void onFinished(File file) {
                Platform.runLater(() -> {
                    idPb.setProgress(1);
                    idFileName.setVisible(true);
                    idFileName.setText(file.getAbsolutePath());
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("打开文件目录？");
                    alert.setContentText("打开文件目录");
                    Optional<ButtonType> buttonType = alert.showAndWait();
                    if (buttonType.get().getButtonData().equals(ButtonBar.ButtonData.OK_DONE)) {
                        try {
                            java.awt.Desktop.getDesktop().open(file.getParentFile());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }

            @Override
            public void onError(Throwable throwable) {
                Platform.runLater(() -> {
                    System.out.println("throwable = " + throwable);
                    idFileName.setVisible(true);
                    idFileName.setText("请重新下载" + throwable.getLocalizedMessage());
                    idPb.setProgress(0);
                });
            }
        });

    }
}
