package com.github.kiulian.downloader.cipher;


public interface Cipher {

    String getSignature(String cipheredSignature);
}
