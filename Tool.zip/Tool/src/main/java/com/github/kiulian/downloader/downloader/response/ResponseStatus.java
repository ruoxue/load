package com.github.kiulian.downloader.downloader.response;

public enum ResponseStatus {
    downloading, completed, canceled, error
}
